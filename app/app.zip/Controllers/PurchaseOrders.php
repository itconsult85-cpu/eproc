<?php

namespace App\Controllers;

use App\Models\ClientPurchaseOrderModel;
use App\Models\ProductModel;
use App\Models\PurchaseOrderItemModel;
use App\Models\PurchaseOrderModel;
use App\Models\QuotationSettingModel;
use App\Models\PurchaseOrderSettingModel;
use App\Models\VendorModel;
use Dompdf\Dompdf;
use Dompdf\Options;

class PurchaseOrders extends BaseController
{
    private PurchaseOrderModel $model;

    public function __construct()
    {
        $this->model = new PurchaseOrderModel();
    }

    public function index()
    {
        return view('purchase_orders/index', ['title' => 'PO OUT Vendor']);
    }

    public function datatable()
    {
        $request = $this->request->getGet();
        $search = trim((string) ($request['search']['value'] ?? ''));
        $start = max(0, (int) ($request['start'] ?? 0));
        $length = max(1, min(100, (int) ($request['length'] ?? 10)));
        $columns = ['responsive', 'number', 'po_no', 'client_po', 'vendor', 'date', 'amount', 'status', 'actions'];
        $orderIndex = (int) ($request['order'][0]['column'] ?? 6);
        $rows = $this->model->listPage($search, $start, $length, $columns[$orderIndex] ?? 'created_at', strtoupper((string) ($request['order'][0]['dir'] ?? 'DESC')));
        $data = array_map(static function (array $row): array {
            $id = public_id((int) $row['id']);
            $statusClass = $row['status'] === 'approved' ? 'success' : ($row['status'] === 'cancelled' ? 'danger' : 'secondary');
            $actions = '<div class="dropdown datatable-actions"><button class="btn btn-sm btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">Aksi</button><ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="/purchase-orders/' . $id . '/pdf" target="_blank" rel="noopener"><i class="bi bi-file-earmark-pdf me-2 text-danger"></i>Print / PDF PO OUT</a></li><li><a class="dropdown-item" href="/purchase-orders/' . $id . '/edit"><i class="bi bi-pencil me-2"></i>Edit PO OUT</a></li><li><form method="post" action="/purchase-orders/' . $id . '/delete" data-confirm data-confirm-title="Hapus PO OUT?">' . csrf_field() . '<button class="dropdown-item text-danger"><i class="bi bi-trash3 me-2"></i>Hapus PO OUT</button></form></li></ul></div>';
            return ['po_no' => '<strong>' . esc($row['po_no']) . '</strong>', 'client_po' => esc($row['client_po_no'] ?? '-'), 'vendor' => esc($row['vendor_name']), 'date' => esc($row['po_date']), 'amount' => 'Rp ' . number_format((float) $row['grand_total'], 0, ',', '.'), 'status' => '<span class="badge text-bg-' . $statusClass . '">' . esc(ucfirst($row['status'])) . '</span>', 'actions' => $actions];
        }, $rows);
        return $this->response->setJSON(['draw' => (int) ($request['draw'] ?? 0), 'recordsTotal' => $this->model->countAll(), 'recordsFiltered' => $this->model->countFiltered($search), 'data' => $data]);
    }

    public function new()
    {
        return view('purchase_orders/form', $this->formContext([], '/purchase-orders'));
    }

    public function edit(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        $po = $this->model->detail($id);
        if (! $po) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return view('purchase_orders/form', $this->formContext($po, '/purchase-orders/' . public_id($id)));
    }

    public function pdf(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        $po = $this->model->detail($id);
        if (! $po) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $vendor = (new VendorModel())->find((int) $po['vendor_id']) ?: [];
        $clientPo = ! empty($po['client_purchase_order_id'])
            ? (new ClientPurchaseOrderModel())->detail((int) $po['client_purchase_order_id'])
            : null;
        $settings = (new PurchaseOrderSettingModel())->current();
        $quotationSettings = (new QuotationSettingModel())->current();
        foreach ($quotationSettings as $key => $value) {
            if (! isset($settings[$key]) || $settings[$key] === null || $settings[$key] === '') $settings[$key] = $value;
        }
        $options = new Options();
        $options->set('isRemoteEnabled', false);
        $dompdf = new Dompdf($options);
        $dompdf->loadHtml(view('purchase_orders/pdf', [
            'po' => $po,
            'vendor' => $vendor,
            'clientPo' => $clientPo,
            'settings' => $settings,
            'logoData' => $this->assetData($settings['logo_path'] ?? null),
            'preparedSignatureData' => $this->assetData($po['created_by_signature_path'] ?? null),
            'signatureData' => $this->assetData($settings['signature_path'] ?? null),
            'stampData' => $this->assetData($settings['stamp_path'] ?? null),
        ]));
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $fileName = preg_replace('/[^A-Za-z0-9._-]/', '-', (string) $po['po_no']) ?: 'po-out';

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="po-out-' . $fileName . '.pdf"')
            ->setBody($dompdf->output());
    }

    public function save(?string $id = null)
    {
        $id = $id ? $this->resolveId($id, $this->model) : null;
        $productMap = [];
        foreach ((new ProductModel())->applyCompanyScope(allowed_company_ids())->findAll() as $product) $productMap[(int) $product['id']] = $product;
        $valid = [];
        $subtotal = 0;
        foreach ((array) $this->request->getPost('items') as $item) {
            $product = $productMap[(int) ($item['product_id'] ?? 0)] ?? null;
            $qty = (float) ($item['quantity'] ?? 0);
            $price = (float) ($item['unit_price'] ?? 0);
            if (! $product || $qty <= 0 || $price < 0) continue;
            $line = $qty * $price;
            $subtotal += $line;
            $valid[] = ['product_id' => (int) $product['id'], 'product_name' => ($product['brand'] ? $product['brand'] . ' / ' : '') . $product['name'], 'description' => trim((string) ($item['description'] ?? $product['description'] ?? '')), 'quantity' => $qty, 'unit' => trim((string) ($item['unit'] ?? 'pcs')) ?: 'pcs', 'unit_price' => $price, 'line_total' => $line];
        }
        $vendorId = (int) $this->request->getPost('vendor_id');
        $clientPoId = (int) $this->request->getPost('client_purchase_order_id');
        $vendor = (new VendorModel())->where('id', $vendorId)->where('is_active', 1)->first();
        if (! $vendorId || ! $vendor || ! $valid) return redirect()->back()->withInput()->with('errors', ['items' => 'Vendor aktif dan minimal satu produk katalog wajib dipilih.']);
        if ($clientPoId && ! (new ClientPurchaseOrderModel())->detail($clientPoId)) return redirect()->back()->withInput()->with('error', 'PO IN klien tidak valid.');
        $usePpn = $this->request->getPost('use_ppn') ? 1 : 0;
        $ppn = max(0, min(100, (float) $this->request->getPost('ppn_percent')));
        $usePph = $this->request->getPost('use_pph') ? 1 : 0;
        $pph = max(0, min(100, (float) $this->request->getPost('pph_percent')));
        $ppnAmount = $usePpn ? $subtotal * $ppn / 100 : 0;
        $pphAmount = $usePph ? $subtotal * $pph / 100 : 0;
        $data = $this->request->getPost(['vendor_id', 'client_purchase_order_id', 'po_no', 'po_date', 'expected_date', 'status', 'notes']);
        $data['vendor_id'] = $vendorId;
        $data['client_purchase_order_id'] = $clientPoId > 0 ? $clientPoId : null;
        $data += ['use_ppn' => $usePpn, 'ppn_percent' => $ppn, 'tax_percent' => $ppn, 'use_pph' => $usePph, 'pph_percent' => $pph, 'pph_amount' => $pphAmount, 'tax_amount' => $ppnAmount, 'subtotal' => $subtotal, 'grand_total' => $subtotal + $ppnAmount - $pphAmount, 'created_at' => date('Y-m-d H:i:s')];
        if (! $id) $data['created_by'] = (int) auth_user('id');
        if (trim((string) ($data['po_no'] ?? '')) === '' || ! in_array($data['status'] ?? '', ['draft', 'sent', 'approved', 'cancelled'], true)) return redirect()->back()->withInput()->with('error', 'Nomor dan status PO OUT wajib valid.');
        $duplicate = $this->model->where('po_no', trim((string) $data['po_no']))->first();
        if ($duplicate && (int) $duplicate['id'] !== (int) ($id ?? 0)) return redirect()->back()->withInput()->with('error', 'Nomor PO OUT sudah digunakan.');
        $db = db_connect();
        try {
            $db->transStart();
            if ($id) {
                $this->model->update($id, $data);
                $poId = $id;
                (new PurchaseOrderItemModel())->where('purchase_order_id', $id)->delete();
            } else {
                $poId = $this->model->insert($data, true);
            }
            foreach ($valid as &$item) $item['purchase_order_id'] = $poId;
            (new PurchaseOrderItemModel())->insertBatch($valid);
            $db->transComplete();
        } catch (\Throwable $exception) {
            $db->transRollback();
            log_message('error', 'PO OUT save exception: {message}', ['message' => $exception->getMessage()]);
            return redirect()->back()->withInput()->with('error', 'PO OUT gagal disimpan. Periksa log aplikasi untuk detail.');
        }
        if ($db->transStatus() === false) {
            log_message('error', 'PO OUT transaction failed: {error}', ['error' => json_encode($db->error(), JSON_UNESCAPED_UNICODE)]);
            return redirect()->back()->withInput()->with('error', 'PO OUT gagal disimpan. Periksa struktur database dan log aplikasi.');
        }
        return redirect()->to('/purchase-orders')->with('message', 'PO OUT ke vendor berhasil disimpan.');
    }

    public function delete(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        if (! $this->model->detail($id)) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        $this->model->delete($id);
        return redirect()->to('/purchase-orders')->with('message', 'PO OUT berhasil dihapus.');
    }

    private function formContext(array $po, string $action): array
    {
        $settings = (new PurchaseOrderSettingModel())->current();
        if (empty($po)) {
            $po = ['use_ppn' => ((float) ($settings['default_tax_percent'] ?? 0)) > 0, 'ppn_percent' => $settings['default_tax_percent'] ?? 11, 'use_pph' => ((float) ($settings['default_pph_percent'] ?? 0)) > 0, 'pph_percent' => $settings['default_pph_percent'] ?? 0];
        }
        return ['title' => empty($po['id']) ? 'Buat PO OUT ke Vendor' : 'Edit PO OUT ke Vendor', 'po' => $po, 'poSettings' => $settings, 'vendors' => (new VendorModel())->where('is_active', 1)->findAll(), 'products' => (new ProductModel())->applyCompanyScope(allowed_company_ids())->orderBy('name')->findAll(), 'clientPurchaseOrders' => (new ClientPurchaseOrderModel())->withQuotation(), 'action' => $action];
    }

    private function assetData(?string $path): ?string
    {
        if (! $path || ! is_file(FCPATH . ltrim($path, '/'))) return null;
        $file = FCPATH . ltrim($path, '/');
        $mime = mime_content_type($file) ?: 'image/png';
        return 'data:' . $mime . ';base64,' . base64_encode((string) file_get_contents($file));
    }
}
