-- Eprocurement schema for CodeIgniter 4.7.4 / MySQL 8+
-- Recommended: use `php spark migrate`; this file is provided for manual deployment.
CREATE TABLE IF NOT EXISTS companies (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(160) NOT NULL UNIQUE, quotation_prefix VARCHAR(12) NULL DEFAULT 'CCIP', quotation_code VARCHAR(30) NULL, quotation_sequence INT UNSIGNED NOT NULL DEFAULT 0, address TEXT NULL, phone VARCHAR(40) NULL, email VARCHAR(160) NULL, pic_name VARCHAR(120) NULL, pic_phone VARCHAR(40) NULL, notes TEXT NULL, created_at DATETIME NULL, updated_at DATETIME NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS products (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, sku VARCHAR(80) NULL, name VARCHAR(180) NOT NULL, brand VARCHAR(120) NULL, description TEXT NULL, datasheet TEXT NULL, technical_specs TEXT NULL, applications TEXT NULL, standards TEXT NULL, datasheet_file_path VARCHAR(500) NULL, image_url VARCHAR(500) NULL, image_path VARCHAR(500) NULL, video_url VARCHAR(500) NULL, video_path VARCHAR(500) NULL, cost_price DECIMAL(18,2) NOT NULL DEFAULT 0, selling_price DECIMAL(18,2) NOT NULL DEFAULT 0, store_name VARCHAR(160) NULL, store_url VARCHAR(500) NULL, store_phone VARCHAR(40) NULL, store_pic VARCHAR(120) NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at DATETIME NULL, updated_at DATETIME NULL, INDEX idx_products_sku (sku)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS quotations (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, company_id INT UNSIGNED NOT NULL, quotation_no VARCHAR(60) NOT NULL UNIQUE, customer_name VARCHAR(180) NULL, customer_address TEXT NULL, customer_phone VARCHAR(40) NULL, attention VARCHAR(180) NULL, title VARCHAR(220) NOT NULL, issue_date DATE NULL, valid_until DATE NULL, validity_days INT NULL, payment_terms VARCHAR(255) NULL, delivery_terms VARCHAR(255) NULL, notes TEXT NULL, status VARCHAR(30) NOT NULL DEFAULT 'draft', subtotal DECIMAL(18,2) NOT NULL DEFAULT 0, tax_percent DECIMAL(5,2) NOT NULL DEFAULT 0, tax_amount DECIMAL(18,2) NOT NULL DEFAULT 0, grand_total DECIMAL(18,2) NOT NULL DEFAULT 0, created_at DATETIME NULL, updated_at DATETIME NULL, INDEX idx_quotations_company (company_id), CONSTRAINT fk_quotations_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE ON UPDATE RESTRICT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS quotation_items (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, quotation_id INT UNSIGNED NOT NULL, product_id INT UNSIGNED NULL, product_name VARCHAR(180) NOT NULL, description TEXT NULL, quantity DECIMAL(12,2) NOT NULL DEFAULT 1, unit VARCHAR(30) NOT NULL DEFAULT 'pcs', unit_price DECIMAL(18,2) NOT NULL DEFAULT 0, discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0, line_total DECIMAL(18,2) NOT NULL DEFAULT 0, INDEX idx_items_quotation (quotation_id), CONSTRAINT fk_items_quotation FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS quotation_settings (id TINYINT UNSIGNED PRIMARY KEY, company_name VARCHAR(180) NULL, office_1 VARCHAR(255) NULL, office_2 VARCHAR(255) NULL, phone VARCHAR(100) NULL, email VARCHAR(160) NULL, tax_id VARCHAR(80) NULL, logo_path VARCHAR(500) NULL, signature_path VARCHAR(500) NULL, stamp_path VARCHAR(500) NULL, signer_name VARCHAR(120) NULL, signer_phone VARCHAR(40) NULL, default_payment_terms VARCHAR(255) NULL, default_validity_days INT NOT NULL DEFAULT 10, default_delivery_terms VARCHAR(255) NULL, default_tax_percent DECIMAL(5,2) NOT NULL DEFAULT 11, created_at DATETIME NULL, updated_at DATETIME NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO quotation_settings (id, default_validity_days, default_tax_percent) VALUES (1, 10, 11) ON DUPLICATE KEY UPDATE id = id;
CREATE TABLE IF NOT EXISTS quotation_status_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, quotation_id INT UNSIGNED NOT NULL, from_status VARCHAR(30) NULL, to_status VARCHAR(30) NOT NULL, changed_by VARCHAR(120) NOT NULL DEFAULT 'system', reason VARCHAR(255) NULL, created_at DATETIME NULL, INDEX idx_status_logs_quotation (quotation_id), CONSTRAINT fk_status_logs_quotation FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS quotation_negotiations (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, quotation_id INT UNSIGNED NOT NULL, round_no INT UNSIGNED NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', proposed_by VARCHAR(120) NOT NULL DEFAULT 'system', customer_message TEXT NULL, internal_notes TEXT NULL, snapshot_json LONGTEXT NOT NULL, subtotal DECIMAL(18,2) NOT NULL DEFAULT 0, tax_amount DECIMAL(18,2) NOT NULL DEFAULT 0, grand_total DECIMAL(18,2) NOT NULL DEFAULT 0, created_at DATETIME NULL, responded_at DATETIME NULL, responded_by VARCHAR(120) NULL, INDEX idx_negotiations_quotation_round (quotation_id, round_no), CONSTRAINT fk_negotiations_quotation FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS tender_documents (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, tender_no VARCHAR(100) NULL, title VARCHAR(220) NOT NULL, procurement_method VARCHAR(80) NULL, issuer_name VARCHAR(180) NULL, description TEXT NULL, issue_date DATE NULL, valid_until DATE NULL, submission_deadline DATETIME NULL, status VARCHAR(30) NOT NULL DEFAULT 'draft', contact_name VARCHAR(120) NULL, contact_email VARCHAR(160) NULL, contact_phone VARCHAR(40) NULL, notes TEXT NULL, file_path VARCHAR(500) NULL, original_file_name VARCHAR(255) NULL, file_mime VARCHAR(120) NULL, file_size BIGINT UNSIGNED NULL, created_by VARCHAR(120) NULL, created_at DATETIME NULL, updated_at DATETIME NULL, INDEX idx_tender_status (status), INDEX idx_tender_valid_until (valid_until)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- Jalankan setelah database/eprocurement.sql dan database/eprocurement_auth.sql.
-- Tabel BAST menyimpan snapshot item dari quotation atau purchase_order agar isi PDF tetap historis.
CREATE TABLE IF NOT EXISTS bast_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bast_no VARCHAR(100) NOT NULL UNIQUE,
  source_type VARCHAR(30) NOT NULL,
  source_id INT UNSIGNED NOT NULL,
  source_no VARCHAR(100) NOT NULL,
  source_title VARCHAR(220) NULL,
  source_date DATE NULL,
  company_id INT UNSIGNED NOT NULL,
  handover_date DATE NOT NULL,
  location VARCHAR(180) NULL,
  recipient_name VARCHAR(160) NOT NULL,
  recipient_position VARCHAR(120) NULL,
  handed_over_by VARCHAR(160) NULL,
  handed_over_position VARCHAR(120) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'completed',
  items_json LONGTEXT NOT NULL,
  notes TEXT NULL,
  created_by VARCHAR(120) NULL,
  created_at DATETIME NULL,
  updated_at DATETIME NULL,
  INDEX idx_bast_source (source_type, source_id),
  INDEX idx_bast_company (company_id),
  INDEX idx_bast_handover_date (handover_date),
  CONSTRAINT fk_bast_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions (permission_key, label, group_name, created_at) VALUES
('bast.view', 'Lihat berita acara serah terima', 'Pengadaan', NOW()),
('bast.create', 'Buat berita acara serah terima', 'Pengadaan', NOW()),
('bast.edit', 'Edit berita acara serah terima', 'Pengadaan', NOW()),
('bast.delete', 'Hapus berita acara serah terima', 'Pengadaan', NOW()),
('bast.export', 'Unduh PDF berita acara serah terima', 'Pengadaan', NOW());
-- Jalankan setelah database/eprocurement.sql dan database/eprocurement_auth.sql.
-- Tabel BAST menyimpan snapshot item dari quotation atau purchase_order agar isi PDF tetap historis.
CREATE TABLE IF NOT EXISTS bast_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bast_no VARCHAR(100) NOT NULL UNIQUE,
  source_type VARCHAR(30) NOT NULL,
  source_id INT UNSIGNED NOT NULL,
  source_no VARCHAR(100) NOT NULL,
  source_title VARCHAR(220) NULL,
  source_date DATE NULL,
  company_id INT UNSIGNED NOT NULL,
  handover_date DATE NOT NULL,
  location VARCHAR(180) NULL,
  recipient_name VARCHAR(160) NOT NULL,
  recipient_position VARCHAR(120) NULL,
  handed_over_by VARCHAR(160) NULL,
  handed_over_position VARCHAR(120) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'completed',
  items_json LONGTEXT NOT NULL,
  notes TEXT NULL,
  created_by VARCHAR(120) NULL,
  created_at DATETIME NULL,
  updated_at DATETIME NULL,
  INDEX idx_bast_source (source_type, source_id),
  INDEX idx_bast_company (company_id),
  INDEX idx_bast_handover_date (handover_date),
  CONSTRAINT fk_bast_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions (permission_key, label, group_name, created_at) VALUES
('bast.view', 'Lihat berita acara serah terima', 'Pengadaan', NOW()),
('bast.create', 'Buat berita acara serah terima', 'Pengadaan', NOW()),
('bast.edit', 'Edit berita acara serah terima', 'Pengadaan', NOW()),
('bast.delete', 'Hapus berita acara serah terima', 'Pengadaan', NOW()),
('bast.export', 'Unduh PDF berita acara serah terima', 'Pengadaan', NOW());
