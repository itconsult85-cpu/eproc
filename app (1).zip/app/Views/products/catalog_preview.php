<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<?php
$rawSpecs = json_decode($product['technical_specs'] ?? '', true) ?: [];
if (is_array($rawSpecs) && (array_key_exists('label', $rawSpecs) || array_key_exists('value', $rawSpecs))) $rawSpecs = [$rawSpecs];
$specs = [];
foreach ((array) $rawSpecs as $key => $spec) {
    $label = is_array($spec) ? trim((string) ($spec['label'] ?? $key)) : trim((string) $key);
    $value = is_array($spec) ? trim((string) ($spec['value'] ?? '')) : (is_scalar($spec) ? trim((string) $spec) : trim((string) json_encode($spec)));
    if ($label !== '' && $value !== '') $specs[] = ['label' => $label, 'value' => $value];
}
?>
<div class="app-content-header">
    <div class="page-intro d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
        <div>
            <h2 class="h5 mb-1">
                <i class="bi bi-box-seam me-2"></i>
                Preview Katalog Produk
            </h2>
            <p class="text-body-secondary mb-0">
                Template disamakan dengan katalog produk pada quotation.
            </p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="<?= esc(site_url('products')) ?>" class="btn btn-outline-secondary text-nowrap"><i
                    class="bi bi-arrow-left me-1"></i>Kembali
            </a>
            <a href="<?= esc(site_url('products/' . public_id((int) $product['id']) . '/catalog')) ?>"
                class="btn btn-success text-nowrap"><i class="bi bi-download me-1"></i>Unduh PDF
            </a>
        </div>
    </div>
</div>
</div>
<div class="alert alert-info">Periksa isi katalog di bawah ini. PDF akan menggunakan template visual yang sama.</div>
<div class="card">
    <div class="card-body">
        <div class="border-bottom pb-3 mb-3 d-flex justify-content-between align-items-start gap-3">
            <div class="d-flex flex-grow-1 align-items-center justify-content-between gap-3">
                <?php if (!empty($settings['logo_path'])): ?>
                <img src="<?= esc(base_url(ltrim($settings['logo_path'], '/'))) ?>" alt="Logo"
                    style="max-width:180px;max-height:60px;object-fit:contain"><?php endif; ?>
                <h2 class="h4 text-primary mb-1">Katalog Produk</h2>
            </div>
            <div class="text-end text-body-secondary small">
                <strong>Produk</strong><br><?= esc($product['name']) ?><br><strong>SKU</strong><br><?= esc($product['sku'] ?: '-') ?>
            </div>
        </div>
        <article class="border rounded p-3">
            <div class="text-white rounded-top px-3 py-2 mb-3" style="background:#d71920">
                <h2 class="h5 mb-0 text-white">
                    <?= esc($product['name']) ?>
                </h2>
                <div class="small">
                    <?= esc($product['brand'] ?? '') ?><?= !empty($product['brand']) && !empty($product['sku']) ? ' · ' : '' ?><?= esc($product['sku'] ?? '') ?>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-sm-3 col-md-2 text-center">
                    <?php if ($imageData): ?><img src="<?= $imageData ?>" alt="<?= esc($product['name']) ?>"
                        class="img-fluid rounded" style="max-height:140px;object-fit:contain">
                    <?php else: ?>
                    <span class="text-body-secondary small">Tidak ada gambar</span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-9 col-md-10">
                    <p>
                        <?= nl2br(esc($product['description'] ?? '')) ?>
                    </p>
                    <?php if ($specs): ?>
                    <div class="fw-semibold">Spesifikasi Teknis</div>
                    <ul class="mb-2"><?php foreach ($specs as $spec): ?>
                        <li>
                            <strong><?= esc($spec['label']) ?>:</strong>
                            <?= nl2br(esc($spec['value'])) ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (!empty($product['applications']) || !empty($product['standards']) || !empty($product['datasheet'])): ?>
            <hr>
            <h3 class="h6">Informasi Produk</h3>
            <dl class="row mb-0">
                <?php if (!empty($product['applications'])): ?>
                <dt class="col-sm-3">
                    Aplikasi / Fungsi
                </dt>
                <dd class="col-sm-9"><?= nl2br(esc($product['applications'])) ?></dd>
                <?php endif; ?>
                <?php if (!empty($product['standards'])): ?>
                <dt class="col-sm-3">
                    Standar / Sertifikasi
                </dt>
                <dd class="col-sm-9"><?= nl2br(esc($product['standards'])) ?></dd>
                <?php endif; ?>
                <?php if (!empty($product['datasheet'])): ?>
                <dt class="col-sm-3">
                    Catatan Datasheet
                </dt>
                <dd class="col-sm-9"><?= nl2br(esc($product['datasheet'])) ?></dd>
                <?php endif; ?>
            </dl>
            <?php endif; ?>
            <?php if (!empty($product['datasheet_file_path'])): ?>
            <hr><a
                href="<?= esc(str_starts_with((string) $product['datasheet_file_path'], 'private/') ? site_url('files/product-datasheets/' . public_id((int) $product['id'])) : base_url(ltrim($product['datasheet_file_path'], '/'))) ?>"
                target="_blank" rel="noopener">
                <i class="bi bi-file-earmark-pdf me-1"></i>Lihat file datasheet
            </a>
            <?php endif; ?>
        </article>
    </div>
</div>
<?= $this->endSection() ?>
