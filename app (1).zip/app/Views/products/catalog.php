<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <style>
    @page {
        margin: 28px 32px 72px;
    }

    body {
        font-family: DejaVu Sans, sans-serif;
        color: #1f2937;
        font-size: 10px;
    }

    h1 {
        margin: 0 0 4px;
        font-size: 20px;
        color: #0f3d67;
    }

    h2 {
        margin: 0 0 3px;
        font-size: 14px;
        color: #0f3d67;
    }

    h3 {
        margin: 12px 0 4px;
        font-size: 11px;
        color: #0f3d67;
    }

    p {
        margin: 3px 0;
        line-height: 1.35;
    }

    .header {
        border-bottom: 2px solid #0f3d67;
        padding-bottom: 9px;
        margin-bottom: 14px;
    }

    .header-table,
    .product-table {
        width: 100%;
        border-collapse: collapse;
    }

    .header-table td {
        vertical-align: top;
    }

    .header-brand-table {
        width: 100%;
        border-collapse: collapse;
    }

    .header-brand-table td {
        vertical-align: middle;
    }

    .header-brand-logo {
        padding-right: 16px;
        white-space: nowrap;
    }

    .header-brand-title h1 {
        margin: 0;
    }

    .header-brand-title {
        text-align: right;
    }

    .logo {
        max-width: 135px;
        max-height: 50px;
    }

    .watermark {
        position: fixed;
        top: 37%;
        left: 22%;
        width: 56%;
        opacity: .075;
        transform: rotate(-30deg);
        z-index: -1;
    }

    .meta {
        text-align: right;
        color: #4b5563;
    }

    .product {
        page-break-inside: auto;
        border: 1px solid #cbd5e1;
        margin-bottom: 13px;
        padding: 0 10px 10px;
    }

    .product-banner {
        background: #d71920;
        color: #fff;
        margin: 0 -10px 10px;
        padding: 9px 12px;
    }

    .product-banner h2 {
        color: #fff;
        margin: 0;
        font-size: 18px;
    }

    .product-banner p {
        margin: 2px 0 0;
        font-size: 9px;
    }

    .product-table td {
        vertical-align: top;
    }

    .product-image-cell {
        width: 125px;
        text-align: center;
        padding-right: 10px;
    }

    .product-image {
        max-width: 112px;
        max-height: 105px;
    }

    .muted {
        color: #64748b;
    }

    .label {
        font-weight: bold;
        color: #475569;
    }

    .spec-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 4px;
    }

    .spec-table td {
        border: 1px solid #b8c1cc;
        padding: 4px 6px;
        vertical-align: top;
    }

    .spec-table td:first-child {
        width: 30%;
        background: #edf0f3;
        font-weight: bold;
        color: #374151;
    }

    .footer {
        position: fixed;
        left: 0;
        right: 0;
        bottom: -48px;
        height: 39px;
        padding-top: 6px;
        border-top: 1px solid #94a3b8;
        color: #64748b;
        font-size: 8px;
    }

    .footer-table {
        width: 100%;
        border-collapse: collapse;
    }

    .footer-table td {
        vertical-align: top;
        line-height: 1.25;
    }

    .footer-right {
        text-align: right;
        white-space: nowrap;
    }

    .footer-company {
        text-align: center;
    }

    .page-number::after {
        content: counter(page);
    }
    </style>
</head>

<body>
    <?php
    if ($logoData) echo '<img src="' . $logoData . '" class="watermark" alt="">';
    $rawSpecs = json_decode($product['technical_specs'] ?? '', true) ?: [];
    if (is_array($rawSpecs) && (array_key_exists('label', $rawSpecs) || array_key_exists('value', $rawSpecs))) $rawSpecs = [$rawSpecs];
    $specs = [];
    foreach ((array) $rawSpecs as $key => $spec) {
        $label = is_array($spec) ? trim((string) ($spec['label'] ?? $key)) : trim((string) $key);
        $value = is_array($spec) ? trim((string) ($spec['value'] ?? '')) : (is_scalar($spec) ? trim((string) $spec) : trim((string) json_encode($spec)));
        if ($label !== '' && $value !== '') $specs[] = ['label' => $label, 'value' => $value];
    }
    ?>
    <div class="header">
        <table class="header-table">
            <tr>
                <td>
                    <table class="header-brand-table">
                        <tr>
                            <?php if ($logoData): ?>
                                <td class="header-brand-logo">
                                    <img src="<?= $logoData ?>" class="logo" alt="Logo">
                                </td>
                            <?php endif; ?>
                            <td class="header-brand-title">
                                <h1>Katalog Produk</h1>
                            </td>
                        </tr>
                    </table>
                </td>
                <td class="meta">
                    <strong>Produk</strong><br><?= esc($product['name']) ?><br>
                    <strong>SKU</strong><br><?= esc($product['sku'] ?: '-') ?>
                </td>
            </tr>
        </table>
    </div>
    <div class="product">
        <div class="product-banner">
            <h2><?= esc($product['name']) ?></h2>
            <p>
                <?= esc($product['brand'] ?? '') ?><?= !empty($product['brand']) && !empty($product['sku']) ? ' · ' : '' ?><?= esc($product['sku'] ?? '') ?>
            </p>
        </div>
        <table class="product-table">
            <tr>
                <td class="product-image-cell">
                    <?php if ($imageData): ?><img src="<?= $imageData ?>" class="product-image"
                        alt="Produk"><?php else: ?><span class="muted">Tidak ada gambar</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (!empty($product['description'])): ?><p><?= nl2br(esc($product['description'])) ?></p>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <?php if ($specs): ?><h3>Spesifikasi Teknis</h3>
        <table class="spec-table">
            <?php foreach ($specs as $spec): ?>
            <tr>
                <td><?= esc($spec['label']) ?></td>
                <td><?= nl2br(esc($spec['value'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
        <?php if (!empty($product['applications']) || !empty($product['standards']) || !empty($product['datasheet'])): ?>
        <h3>Informasi Produk</h3>
        <table class="spec-table">
            <?php if (!empty($product['applications'])): ?>
            <tr>
                <td>Aplikasi / Fungsi</td>
                <td><?= nl2br(esc($product['applications'])) ?></td>
            </tr>
            <?php endif; ?>
            <?php if (!empty($product['standards'])): ?>
            <tr>
                <td>Standar / Sertifikasi</td>
                <td><?= nl2br(esc($product['standards'])) ?></td>
            </tr>
            <?php endif; ?>
            <?php if (!empty($product['datasheet'])): ?>
            <tr>
                <td>Catatan Datasheet</td>
                <td><?= nl2br(esc($product['datasheet'])) ?></td>
            </tr>
            <?php endif; ?>
        </table>
        <?php endif; ?>
    </div>
    <div class="footer">
        <table class="footer-table">
            <tr>
                <td class="footer-company" colspan="2">
                    <strong>PT TRISENTOSA RAYA ESOLUSI</strong><br>
                    Menyediakan Solusi Keamanan Terbaik untuk Industri Anda<br>
                    www.trisentosaraya.co.id | info@trisentosaraya.co.id
                </td>
            </tr>
        </table>
    </div>
</body>

</html>
