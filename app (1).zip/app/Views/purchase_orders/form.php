<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="app-content-header">
    <div class="page-intro d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
        <div>
            <h2 class="h5 mb-1">
                <i class="bi bi-cart-check me-2"></i>
                <?= esc($title) ?>
            </h2>
            <p class="text-body-secondary mb-0">
                PO OUT dikirim ke vendor untuk memenuhi barang pada PO IN klien.
            </p>
        </div>
        <a href="/purchase-orders" class="btn btn-light text-nowrap">
            <i class="bi bi-arrow-left me-1"></i>Kembali
        </a>
    </div>
</div>
<form method="post" action="<?= esc($action) ?>" class="card form-card" data-po-form><?= csrf_field() ?><div
        class="card-body">
        <div class="row g-3 mb-4">
            <div class="col-lg-4">
                <label class="field-label required">
                    Vendor
                </label>
                <select name="vendor_id" required class="form-select" data-searchable-select
                    data-placeholder="Cari vendor...">
                    <option value=""></option>
                    <?php foreach ($vendors as $v): ?>
                        <option value="<?= $v['id'] ?>" <?= ($po['vendor_id'] ?? '') == $v['id'] ? 'selected' : '' ?>>
                            <?= esc($v['name']) ?><?= !empty($v['code']) ? ' · ' . esc($v['code']) : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-4">
                <label class="field-label">
                    Referensi PO IN Klien
                </label>
                <select name="client_purchase_order_id" class="form-select" data-searchable-select
                    data-placeholder="Opsional: pilih PO IN">
                    <option value="">Tanpa referensi PO IN</option>
                    <?php foreach ($clientPurchaseOrders as $clientPo): ?>
                        <option value="<?= (int) $clientPo['id'] ?>"
                            <?= (int)($po['client_purchase_order_id'] ?? 0) === (int)$clientPo['id'] ? 'selected' : '' ?>>
                            <?= esc($clientPo['po_no']) ?> — <?= esc($clientPo['company_name'] ?? '') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2">
                <label class="field-label required">Nomor PO OUT</label>
                <select class="form-select mb-2" data-number-mode-select>
                    <option value="auto">Otomatis</option>
                    <option value="manual">Manual</option>
                </select>
                <input name="po_no" required class="form-control" data-number-input
                    value="<?= esc($po['po_no'] ?? 'PO-OUT-' . date('YmdHis')) ?>">
            </div>
            <div class="col-lg-2">
                <label class="field-label">
                    Tanggal
                </label>
                <input type="date" name="po_date" class="form-control"
                    value="<?= esc($po['po_date'] ?? date('Y-m-d')) ?>">
            </div>
            <div class="col-lg-3">
                <label class="field-label">
                    Status
                </label>
                <select name="status" class="form-select" data-searchable-select data-placeholder="Status">
                    <option value="draft" <?= ($po['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                    <option value="sent" <?= ($po['status'] ?? '') === 'sent' ? 'selected' : '' ?>>Dikirim ke vendor
                    </option>
                    <option value="approved" <?= ($po['status'] ?? '') === 'approved' ? 'selected' : '' ?>>Disetujui
                    </option>
                    <option value="cancelled" <?= ($po['status'] ?? '') === 'cancelled' ? 'selected' : '' ?>>Dibatalkan
                    </option>
                </select>
            </div>
            <div class="col-lg-3">
                <label class="field-label">
                    Perkiraan Tiba
                </label>
                <input type="date" name="expected_date" class="form-control"
                    value="<?= esc($po['expected_date'] ?? '') ?>">
            </div>
        </div>
        <div class="section-heading d-flex justify-content-between align-items-center mb-2">
            <div>
                <h2 class="h6 mb-1">
                    Item Produk
                </h2>
                <span class="small text-body-secondary">Satu produk hanya dapat dipilih satu kali dalam PO OUT.</span>
            </div>
            <button type="button" class="btn btn-sm btn-outline-primary" data-po-add><i
                    class="bi bi-plus-lg me-1"></i>Tambah produk
            </button>
        </div>
        <div class="table-responsive po-items-wrapper">
            <table class="table table-sm align-middle po-items-table">
                <thead>
                    <tr>
                        <th style="min-width:280px">Produk katalog</th>
                        <th style="min-width:180px">Deskripsi</th>
                        <th style="width:95px">Qty</th>
                        <th style="width:105px">Satuan</th>
                        <th style="width:145px">Harga beli</th>
                        <th style="width:48px"></th>
                    </tr>
                </thead>
                <tbody data-po-items>
                    <?php $items = $po['items'] ?? [[]];
                    foreach ($items as $i => $item): ?>
                        <tr data-po-row>
                            <td>
                                <select name="items[<?= $i ?>][product_id]" class="form-select" data-po-product
                                    data-searchable-select data-placeholder="Cari produk..." required>
                                    <option value=""></option>
                                    <?php foreach ($products as $p): ?>
                                        <option value="<?= $p['id'] ?>"
                                            <?= (int)($item['product_id'] ?? 0) === (int)$p['id'] ? 'selected' : '' ?>>
                                            <?= esc(($p['brand'] ? $p['brand'] . ' / ' : '') . $p['name']) ?><?= !empty($p['sku']) ? ' · ' . esc($p['sku']) : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input name="items[<?= $i ?>][description]" class="form-control"
                                    value="<?= esc($item['description'] ?? '') ?>">
                            </td>
                            <td>
                                <input type="number" step="0.01" min="0.01" name="items[<?= $i ?>][quantity]"
                                    class="form-control" value="<?= esc($item['quantity'] ?? 1) ?>">
                            </td>
                            <td>
                                <input name="items[<?= $i ?>][unit]" class="form-control"
                                    value="<?= esc($item['unit'] ?? 'pcs') ?>">
                            </td>
                            <td>
                                <input type="number" step="0.01" min="0" name="items[<?= $i ?>][unit_price]"
                                    class="form-control"
                                    value="<?= ($item['unit_price'] ?? '') !== '' && (float)$item['unit_price'] > 0 ? esc($item['unit_price']) : '' ?>"
                                    placeholder="Isi harga">
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-danger" data-po-remove
                                    title="Hapus baris"><i class="bi bi-trash3"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="tax-section">
            <div class="tax-section-title"><i class="bi bi-percent"></i><span>Pajak Pembelian</span><small
                    class="text-body-secondary fw-normal">Aktifkan pajak yang berlaku</small></div>
            <div class="tax-stack">
                <div class="tax-row">
                    <div class="form-check tax-option"><input class="form-check-input" type="checkbox" name="use_ppn"
                            value="1" id="use_ppn" <?= !empty($po['use_ppn']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="use_ppn">
                            Gunakan PPN
                        </label>
                    </div>
                    <div class="tax-rate tax-field">
                        <label class="field-label" for="ppn_percent">
                            PPN (%)
                        </label>
                        <input id="ppn_percent" type="number" step="0.01" min="0" name="ppn_percent"
                            class="form-control" value="<?= esc($po['ppn_percent'] ?? 11) ?>">
                    </div>
                </div>
                <div class="tax-row">
                    <div class="form-check tax-option">
                        <input class="form-check-input" type="checkbox" name="use_pph" value="1" id="use_pph"
                            <?= !empty($po['use_pph']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="use_pph">
                            Gunakan PPh
                        </label>
                    </div>
                    <div class="tax-rate tax-field">
                        <label class="field-label" for="pph_percent">
                            PPh (%)
                        </label>
                        <input id="pph_percent" type="number" step="0.01" min="0" name="pph_percent"
                            class="form-control" value="<?= esc($po['pph_percent'] ?? 0) ?>">
                    </div>
                </div>
            </div>
            <div class="col-12">
                <label class="field-label" for="po_notes">
                    Catatan
                </label>
                <textarea id="po_notes" name="notes" rows="3"
                    class="form-control"><?= esc($po['notes'] ?? '') ?></textarea>
            </div>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-end gap-2">
        <a href="/purchase-orders" class="btn btn-light">
            Batal
        </a>
        <button class="btn btn-primary"><i class="bi bi-save me-1"></i>Simpan PO OUT
        </button>
    </div>
</form>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('[data-po-form]');
        if (!form) return;
        const body = form.querySelector('[data-po-items]');
        let nextIndex = body.querySelectorAll('[data-po-row]').length;
        const products =
            <?= json_encode(array_map(static fn($p) => ['id' => $p['id'], 'label' => ($p['brand'] ? $p['brand'] . ' / ' : '') . $p['name'] . (!empty($p['sku']) ? ' · ' . $p['sku'] : '')], $products), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;

        function initSelects(root) {
            if (window.jQuery && jQuery.fn.select2) jQuery(root).find('select[data-searchable-select]').each(
                function() {
                    const s = jQuery(this);
                    if (!s.hasClass('select2-hidden-accessible')) s.select2({
                        theme: 'bootstrap-5',
                        width: '100%',
                        placeholder: s.data('placeholder'),
                        allowClear: true,
                        dropdownParent: form
                    });
                });
        }

        function refresh() {
            const selected = [...body.querySelectorAll('[data-po-product]')].map(s => s.value).filter(Boolean);
            body.querySelectorAll('[data-po-product]').forEach(select => {
                [...select.options].forEach(option => {
                    option.disabled = !!option.value && option.value !== select.value && selected
                        .includes(option.value);
                });
                if (window.jQuery && jQuery.fn.select2) jQuery(select).trigger('change.select2');
            });
        }

        function makeRow(i) {
            const opts = products.map(p => `<option value="${p.id}">${p.label}</option>`).join('');
            return `<tr data-po-row><td><select name="items[${i}][product_id]" class="form-select" data-po-product data-searchable-select data-placeholder="Cari produk..." required><option value=""></option>${opts}</select></td><td><input name="items[${i}][description]" class="form-control"></td><td><input type="number" step="0.01" min="0.01" name="items[${i}][quantity]" class="form-control" value="1"></td><td><input name="items[${i}][unit]" class="form-control" value="pcs"></td><td><input type="number" step="0.01" min="0" name="items[${i}][unit_price]" class="form-control" placeholder="Isi harga"></td><td><button type="button" class="btn btn-sm btn-outline-danger" data-po-remove><i class="bi bi-trash3"></i></button></td></tr>`;
        }
        initSelects(form);
        refresh();
        form.addEventListener('click', function(e) {
            if (e.target.closest('[data-po-add]')) {
                body.insertAdjacentHTML('beforeend', makeRow(nextIndex++));
                initSelects(body.lastElementChild);
                refresh();
            }
            if (e.target.closest('[data-po-remove]')) {
                const rows = body.querySelectorAll('[data-po-row]');
                if (rows.length > 1) {
                    const select = e.target.closest('[data-po-row]').querySelector('[data-po-product]');
                    if (window.jQuery && jQuery.fn.select2) jQuery(select).select2('destroy');
                    e.target.closest('[data-po-row]').remove();
                    refresh();
                }
            }
        });
        form.addEventListener('change', function(e) {
            if (!e.target.matches('[data-po-product]')) return;
            const value = e.target.value;
            const duplicate = [...body.querySelectorAll('[data-po-product]')].filter(s => s.value ===
                value);
            if (value && duplicate.length > 1) {
                alert('Produk tersebut sudah dipilih pada baris lain.');
                if (window.jQuery && jQuery.fn.select2) jQuery(e.target).val(null).trigger('change');
                else e.target.value = '';
            }
            refresh();
        });
    });
</script>
<?= $this->endSection() ?>
