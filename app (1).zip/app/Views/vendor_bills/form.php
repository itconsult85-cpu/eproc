<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="app-content-header">
    <div class="page-intro d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
        <div>
            <h2 class="h5 mb-1">
                <i class="bi bi-journal-text me-2"></i>
                <?= esc($title) ?>
            </h2>
            <p class="text-body-secondary mb-0">
                Kelola tagihan vendor, pembayaran, dan perhitungan pajak.
            </p>
        </div><a href="/vendor-bills" class="btn btn-light text-nowrap">
            <i class="bi bi-arrow-left me-1"></i>Kembali
        </a>
    </div>
</div>
<form method="post" enctype="multipart/form-data" action="<?= esc($action) ?>" class="card form-card"
    data-vendor-bill-form>
    <div class="card-body row g-3"><?= csrf_field() ?>
        <div class="col-md-4">
            <label class="form-label">
                Vendor *
            </label>
            <select name="vendor_id" required class="form-select">
                <option value="">Pilih vendor</option>
                <?php foreach ($vendors as $v): ?>
                <option value="<?= $v['id'] ?>" <?= ($bill['vendor_id'] ?? '') == $v['id'] ? 'selected' : '' ?>>
                    <?= esc($v['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Nomor Tagihan *</label>
            <select class="form-select mb-2" data-number-mode-select>
                <option value="auto">Otomatis</option>
                <option value="manual">Manual</option>
            </select>
            <input name="bill_no" required class="form-control" data-number-input
                value="<?= esc($bill['bill_no'] ?? 'BILL-' . date('YmdHis')) ?>">
        </div>
        <div class="col-md-2">
            <label class="form-label">
                Tanggal
            </label>
            <input type="date" name="bill_date" class="form-control"
                value="<?= esc($bill['bill_date'] ?? date('Y-m-d')) ?>">
        </div>
        <div class="col-md-2">
            <label class="form-label">
                Jatuh Tempo
            </label>
            <input type="date" name="due_date" class="form-control" value="<?= esc($bill['due_date'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">
                DPP / Nilai Dasar Tagihan
            </label>
            <input type="number" step="0.01" name="amount" class="form-control"
                value="<?= esc($bill['amount'] ?? 0) ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">
                Status
            </label>
            <select name="status" class="form-select">
                <option value="unpaid" <?= ($bill['status'] ?? 'unpaid') === 'unpaid' ? 'selected' : '' ?>>
                    Belum dibayar
                </option>
                <option value="partial" <?= ($bill['status'] ?? '') === 'partial' ? 'selected' : '' ?>>
                    Dibayar sebagian
                </option>
                <option value="paid" <?= ($bill['status'] ?? '') === 'paid' ? 'selected' : '' ?>>
                    Sudah dibayar
                </option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">
                Tanggal Bayar
            </label>
            <input type="date" name="paid_date" class="form-control" value="<?= esc($bill['paid_date'] ?? '') ?>">
        </div>
        <div class="col-12 tax-section">
            <div class="tax-section-title">
                <i class="bi bi-percent"></i>
                <span>Perhitungan Pajak</span>
                <small class="text-body-secondary fw-normal">Nilai bersih = DPP + PPN - PPh</small>
            </div>
            <div class="tax-stack">
                <div class="tax-row">
                    <div class="form-check tax-option">
                        <input class="form-check-input" type="checkbox" name="use_ppn" value="1" id="bill_use_ppn"
                            <?= !empty($bill['use_ppn']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="bill_use_ppn">
                            Gunakan PPN
                        </label>
                    </div>
                    <div class="tax-rate tax-field">
                        <label class="field-label" for="bill_ppn_percent">
                            PPN (%)
                        </label>
                        <input id="bill_ppn_percent" type="number" step="0.01" min="0" name="ppn_percent"
                            class="form-control" value="<?= esc($bill['ppn_percent'] ?? 11) ?>">
                    </div>
                </div>
                <div class="tax-row">
                    <div class="form-check tax-option">
                        <input class="form-check-input" type="checkbox" name="use_pph" value="1" id="bill_use_pph"
                            <?= !empty($bill['use_pph']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="bill_use_pph">
                            Gunakan PPh
                        </label>
                    </div>
                    <div class="tax-rate tax-field">
                        <label class="field-label" for="bill_pph_percent">
                            PPh (%)
                        </label>
                        <input id="bill_pph_percent" type="number" step="0.01" min="0" name="pph_percent"
                            class="form-control" value="<?= esc($bill['pph_percent'] ?? 0) ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <label class="form-label">
                Referensi Pembayaran
            </label>
            <input name="payment_reference" class="form-control" value="<?= esc($bill['payment_reference'] ?? '') ?>">
        </div>
        <div class="col-md-6">
            <label class="form-label">
                Bukti Pembayaran
            </label>
            <input type="file" name="proof" class="form-control"
                accept=".jpg,.jpeg,.png,.webp,.pdf"><?php if (!empty($bill['proof_path'])): ?>
            <a href="<?= esc(site_url('files/vendor-bill-proofs/' . public_id((int) $bill['id']))) ?>" target="_blank"
                rel="noopener">
                Lihat bukti
            </a>
            <?php endif; ?>
        </div>
        <div class="col-12">
            <label class="form-label">
                Catatan
            </label>
            <textarea name="notes" class="form-control"><?= esc($bill['notes'] ?? '') ?></textarea>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-end gap-2">
        <a href="/vendor-bills" class="btn btn-light">
            Batal
        </a><button class="btn btn-primary">Simpan Tagihan</button>
    </div>
</form>
<?= $this->endSection() ?>
