<?= $this->extend('layout') ?><?= $this->section('content') ?><div class="app-content-header">
    <div class="page-intro d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
        <div>
            <h2 class="h5 mb-1"><i class="bi bi-journal-text me-2"></i>Tagihan Vendor</h2>
            <p class="text-body-secondary mb-0">Pantau tagihan pembelian dan status pembayaran vendor.</p>
        </div>
        <?php if (can('vendor_bills.create')): ?>
        <a href="/vendor-bills/new" class="btn btn-primary text-nowrap">
            <i class="bi bi-plus-lg me-1"></i>
            Tambah Tagihan
        </a>
        <?php endif; ?>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <table id="vendor-bills-table" class="table table-hover align-middle w-100">
            <thead>
                <tr>
                    <th></th>
                    <th>No.</th>
                    <th>Tagihan</th>
                    <th>Vendor</th>
                    <th>Nilai</th>
                    <th>Jatuh Tempo</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
        </table>
    </div>
</div><?= $this->endSection() ?>