<?php

namespace App\Controllers;

use App\Libraries\SecureFileStorage;
use App\Models\CompanyModel;
use App\Models\ProductModel;
use App\Models\QuotationSettingModel;
use Dompdf\Dompdf;
use Dompdf\Options;

class Products extends BaseController
{
    private ProductModel $model;

    public function __construct()
    {
        $this->model = new ProductModel();
    }

    public function index()
    {
        return view('products/index', ['title' => 'Katalog Produk']);
    }

    public function datatable()
    {
        $request = $this->request->getGet();
        $draw = (int) ($request['draw'] ?? 0);
        $start = max(0, (int) ($request['start'] ?? 0));
        $length = min(100, max(1, (int) ($request['length'] ?? 10)));
        $search = trim((string) ($request['search']['value'] ?? ''));
        $allowedCompanies = allowed_company_ids();
        $totalQuery = (new ProductModel())->applyCompanyScope($allowedCompanies);
        $total = $totalQuery->countAllResults();
        $builder = $this->model->applyCompanyScope($allowedCompanies)->builder();

        if ($search !== '') {
            $builder->groupStart()->like('name', $search)->orLike('sku', $search)->orLike('brand', $search)->orLike('store_name', $search)->groupEnd();
        }
        $filtered = $builder->countAllResults(false);
        $columns = ['name', 'name', 'name', 'name', 'cost_price', 'selling_price', 'store_name', 'created_at'];
        $orderColumn = (int) ($request['order'][0]['column'] ?? 3);
        $orderDirection = strtolower((string) ($request['order'][0]['dir'] ?? 'asc')) === 'desc' ? 'desc' : 'asc';
        $builder->orderBy($columns[$orderColumn] ?? 'name', $orderDirection);
        $rows = $builder->get($length, $start)->getResultArray();

        $data = array_map(static function (array $row): array {
            $media = $row['image_path']
                ? '<img src="' . esc($row['image_path']) . '" class="rounded border object-fit-cover" style="width:52px;height:52px" alt="' . esc($row['name']) . '">'
                : '<span class="d-inline-flex bg-body-secondary rounded align-items-center justify-content-center" style="width:52px;height:52px"><i class="bi bi-image text-secondary"></i></span>';
            if ($row['video_path']) $media .= '<div class="small text-primary mt-1"><i class="bi bi-camera-video"></i> Video</div>';
            $details = '<strong>' . esc($row['name']) . '</strong><div class="small text-body-secondary">' . esc(trim(($row['sku'] ?? '') . ' ' . ($row['brand'] ?? '')) ?: 'SKU belum diisi') . '</div>';
            $publicId = public_id((int) $row['id']);
            if ($row['datasheet_file_path']) {
                $datasheetUrl = str_starts_with((string) $row['datasheet_file_path'], 'private/')
                    ? site_url('files/product-datasheets/' . $publicId)
                    : $row['datasheet_file_path'];
                $details .= '<a href="' . esc($datasheetUrl) . '" target="_blank" rel="noopener" class="small text-danger"><i class="bi bi-file-pdf"></i> Datasheet PDF</a>';
            }
            $actions = '';
            $actions .= '<li><a class="dropdown-item" href="/products/' . $publicId . '/catalog/preview"><i class="bi bi-eye me-2 text-success"></i>Lihat katalog</a></li>';
            $actions .= '<li><a class="dropdown-item" href="/products/' . $publicId . '/catalog"><i class="bi bi-file-earmark-pdf me-2 text-danger"></i>Unduh katalog PDF</a></li>';
            if (can('products.edit')) {
                $actions .= '<li><a class="dropdown-item" href="/products/' . $publicId . '/edit"><i class="bi bi-pencil me-2 text-warning"></i>Edit produk</a></li>';
            }
            if (can('products.delete')) {
                $actions .= '<li><form method="post" action="/products/' . $publicId . '/delete" data-confirm data-confirm-title="Hapus produk?" data-confirm-message="Produk ini akan dihapus dan tidak dapat dipulihkan." data-confirm-label="Ya, hapus" data-confirm-variant="danger">' . csrf_field() . '<button class="dropdown-item text-danger" type="submit"><i class="bi bi-trash3 me-2"></i>Hapus produk</button></form></li>';
            }
            $actions = $actions !== ''
                ? '<div class="dropdown datatable-actions"><button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-boundary="viewport" aria-expanded="false"><i class="bi bi-three-dots me-1"></i>Aksi</button><ul class="dropdown-menu dropdown-menu-end shadow-sm">' . $actions . '</ul></div>'
                : '<span class="text-body-secondary small">Tidak ada aksi</span>';
            return ['media' => $media, 'product' => $details, 'cost_price' => 'Rp ' . number_format((float) $row['cost_price'], 0, ',', '.'), 'selling_price' => 'Rp ' . number_format((float) $row['selling_price'], 0, ',', '.'), 'store' => esc($row['store_name'] ?: '-') . '<div class="small text-body-secondary">' . esc($row['store_phone'] ?: '') . '</div>', 'actions' => $actions];
        }, $rows);

        return $this->response->setJSON(['draw' => $draw, 'recordsTotal' => $total, 'recordsFiltered' => $filtered, 'data' => $data]);
    }

    public function new()
    {
        return view('products/form', ['title' => 'Tambah Produk', 'product' => [], 'action' => '/products', 'companies' => $this->availableCompanies()]);
    }

    public function create()
    {
        return $this->save();
    }

    public function edit(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        $product = $this->model->find($id);
        if (! $product || ! $this->model->applyCompanyScope(allowed_company_ids())->find($id)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        return view('products/form', ['title' => 'Edit Produk', 'product' => $product, 'assignedCompanies' => $this->model->companyIds($id), 'action' => '/products/' . public_id($id), 'companies' => $this->availableCompanies()]);
    }

    public function update(string $id)
    {
        return $this->save($this->resolveId($id, $this->model));
    }

    public function catalogPreview(string $id)
    {
        $product = $this->catalogProduct($id);
        return view('products/catalog_preview', [
            'title' => 'Preview Katalog Produk',
            'product' => $product,
            'settings' => (new QuotationSettingModel())->current(),
            'imageData' => $this->assetData($product['image_path'] ?? null),
        ]);
    }

    public function catalog(string $id)
    {
        $product = $this->catalogProduct($id);
        $settings = (new QuotationSettingModel())->current();
        $options = new Options();
        $options->set('isRemoteEnabled', false);
        $dompdf = new Dompdf($options);
        $dompdf->loadHtml(view('products/catalog', [
            'product' => $product,
            'settings' => $settings,
            'imageData' => $this->assetData($product['image_path'] ?? null),
            'logoData' => $this->assetData($settings['logo_path'] ?? null),
        ]));
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="katalog-produk-' . preg_replace('/[^A-Za-z0-9_-]/', '-', (string) ($product['sku'] ?: $product['id'])) . '.pdf"')
            ->setBody($dompdf->output());
    }

    private function catalogProduct(string $value): array
    {
        $id = $this->resolveId($value, $this->model);
        $product = $this->model->applyCompanyScope(allowed_company_ids())->find($id);
        if (! $product) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return $product;
    }

    private function assetData(?string $path): ?string
    {
        if (! $path || ! is_file(FCPATH . ltrim($path, '/'))) {
            return null;
        }
        $file = FCPATH . ltrim($path, '/');
        $mime = mime_content_type($file) ?: 'image/png';
        return 'data:' . $mime . ';base64,' . base64_encode((string) file_get_contents($file));
    }

    private function save(?int $id = null)
    {
        $data = $this->request->getPost(['sku', 'name', 'brand', 'description', 'datasheet', 'applications', 'standards', 'cost_price', 'selling_price', 'store_name', 'store_url', 'store_phone', 'store_pic', 'is_active']);
        $companyIds = array_values(array_unique(array_filter(array_map('intval', (array) $this->request->getPost('company_ids')), static fn (int $id): bool => $id > 0)));
        $allowedCompanies = allowed_company_ids();
        if ($allowedCompanies !== null) $companyIds = array_values(array_intersect($companyIds, $allowedCompanies));
        if ($allowedCompanies !== null && ! $companyIds) {
            return redirect()->back()->withInput()->with('error', 'Minimal satu perusahaan wajib dipilih.');
        }
        if ($companyIds) {
            $validCompanyCount = (new CompanyModel())->whereIn('id', $companyIds)->countAllResults();
            if ($validCompanyCount !== count($companyIds)) {
                return redirect()->back()->withInput()->with('error', 'Ada perusahaan yang tidak valid.');
            }
        }
        foreach (['description', 'applications', 'datasheet'] as $field) {
            if (array_key_exists($field, $data)) {
                $data[$field] = trim((string) $data[$field]);
            }
        }
        if (! $this->validateData($data, ['name' => 'required|max_length[180]', 'selling_price' => 'permit_empty|decimal'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $labels = (array) $this->request->getPost('spec_label');
        $values = (array) $this->request->getPost('spec_value');
        $specifications = [];
        foreach ($labels as $index => $label) {
            $label = trim((string) $label);
            $value = trim((string) ($values[$index] ?? ''));
            if ($label !== '' && $value !== '') {
                $specifications[] = ['label' => $label, 'value' => $value];
            }
        }
        $data['technical_specs'] = $specifications ? json_encode($specifications, JSON_UNESCAPED_UNICODE) : null;

        $existing = $id ? $this->model->applyCompanyScope($allowedCompanies)->find($id) : [];
        if ($id && ! $existing) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        $uploads = [
            'image' => ['image_path', ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'], 5242880, 'Format atau ukuran file gambar tidak valid.'],
            'video' => ['video_path', ['mp4' => 'video/mp4', 'webm' => 'video/webm', 'mov' => 'video/quicktime'], 52428800, 'Format atau ukuran file video tidak valid.'],
            'datasheet_file' => ['datasheet_file_path', ['pdf' => 'application/pdf'], 20971520, 'Datasheet harus berupa PDF maksimal 20 MB.'],
        ];
        foreach ($uploads as $field => [$column, $extensions, $maxSize, $message]) {
            $file = $this->request->getFile($field);
            if ($file && $file->isValid() && ! $file->hasMoved()) {
                $extension = strtolower($file->getExtension());
                if ($file->getSize() > $maxSize || ! isset($extensions[$extension]) || strtolower((string) $file->getMimeType()) !== $extensions[$extension]) {
                    return redirect()->back()->withInput()->with('errors', [$field => $message]);
                }
                if ($field === 'datasheet_file') {
                    try {
                        $stored = SecureFileStorage::store($file, $extensions, $maxSize, 'product-datasheets');
                    } catch (\RuntimeException $exception) {
                        return redirect()->back()->withInput()->with('errors', [$field => $message]);
                    }
                    if ($existing && ! empty($existing[$column])) SecureFileStorage::remove($existing[$column]);
                    $data[$column] = $stored['path'];
                    continue;
                }
                $directory = FCPATH . 'uploads/products';
                if (! is_dir($directory)) {
                    mkdir($directory, 0755, true);
                }
                $newName = $file->getRandomName();
                $file->move($directory, $newName);
                $data[$column] = '/uploads/products/' . $newName;
            } elseif ($existing && ! empty($existing[$column])) {
                $data[$column] = $existing[$column];
            }
        }
        $data['company_id'] = null;
        $db = db_connect();
        $db->transStart();
        if ($id) {
            $this->model->update($id, $data);
            $productId = $id;
        } else {
            $productId = (int) $this->model->insert($data, true);
        }
        $this->model->replaceCompanyAccess($productId, $companyIds);
        $db->transComplete();
        if ($db->transStatus() === false) return redirect()->back()->withInput()->with('error', 'Produk gagal disimpan.');
        return redirect()->to('/products')->with('message', $id ? 'Produk berhasil diperbarui.' : 'Produk berhasil ditambahkan.');
    }

    private function availableCompanies(): array
    {
        $model = new CompanyModel();
        $allowed = allowed_company_ids();
        if ($allowed !== null) {
            if (! $allowed) return [];
            $model->whereIn('id', $allowed);
        }
        return $model->orderBy('name', 'ASC')->findAll();
    }

    public function delete(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        if (! $this->model->applyCompanyScope(allowed_company_ids())->find($id)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        $this->model->delete($id);
        return redirect()->to('/products')->with('message', 'Produk berhasil dihapus.');
    }
}
