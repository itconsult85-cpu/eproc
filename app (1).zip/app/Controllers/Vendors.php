<?php

namespace App\Controllers;

use App\Models\VendorModel;

class Vendors extends BaseController
{
    private VendorModel $model;
    public function __construct()
    {
        $this->model = new VendorModel();
    }
    public function index()
    {
        return view('vendors/index', ['title' => 'Vendor']);
    }
    public function datatable()
    {
        $r = $this->request->getGet();
        $q = trim((string)($r['search']['value'] ?? ''));
        $b = $this->model;
        if ($q) $b = $b->groupStart()->like('name', $q)->orLike('code', $q)->orLike('pic_name', $q)->groupEnd();
        $rows = $b->orderBy('created_at', 'DESC')->findAll((int)($r['length'] ?? 10), (int)($r['start'] ?? 0));
        $all = $this->model->countAll();
        $data = array_map(static function ($x) {
            $id = public_id((int)$x['id']);
            $a = '<div class="dropdown datatable-actions"><button class="btn btn-sm btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">Aksi</button><ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="/vendors/' . $id . '/edit"><i class="bi bi-pencil me-2"></i>Edit vendor</a></li><li><form method="post" action="/vendors/' . $id . '/delete" data-confirm data-confirm-title="Hapus vendor?">' . csrf_field() . '<button class="dropdown-item text-danger"><i class="bi bi-trash me-2"></i>Hapus vendor</button></form></li></ul></div>';
            return ['name' => '<strong>' . esc($x['name']) . '</strong><div class="small text-body-secondary">' . esc($x['code'] ?? '') . '</div>', 'pic' => esc($x['pic_name'] ?? '-'), 'contact' => esc($x['phone'] ?? '-'), 'status' => $x['is_active'] ? '<span class="badge text-bg-success">Aktif</span>' : '<span class="badge text-bg-secondary">Nonaktif</span>', 'actions' => $a];
        }, $rows);
        return $this->response->setJSON(['draw' => (int)($r['draw'] ?? 0), 'recordsTotal' => $all, 'recordsFiltered' => count($data), 'data' => $data]);
    }
    public function new()
    {
        return view('vendors/form', ['title' => 'Tambah Vendor', 'vendor' => [], 'action' => '/vendors']);
    }
    public function edit(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        return view('vendors/form', ['title' => 'Edit Vendor', 'vendor' => $this->model->find($id), 'action' => '/vendors/' . public_id($id)]);
    }
    public function save(?string $id = null)
    {
        $id = $id ? $this->resolveId($id, $this->model) : null;
        $data = $this->request->getPost(['name', 'code', 'address', 'phone', 'email', 'pic_name', 'payment_terms', 'bank_name', 'bank_account_name', 'bank_account_number', 'bank_branch', 'tax_id', 'notes']);
        $data['is_active'] = $this->request->getPost('is_active') ? 1 : 0;
        if (!$data['name']) return redirect()->back()->withInput()->with('errors', ['name' => 'Nama vendor wajib diisi.']);
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to('/vendors')->with('message', 'Vendor berhasil disimpan.');
    }
    public function delete(string $id)
    {
        $id = $this->resolveId($id, $this->model);
        $this->model->delete($id);
        return redirect()->to('/vendors')->with('message', 'Vendor berhasil dihapus.');
    }
}
